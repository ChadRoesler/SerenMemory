"""HTTP routes for SerenMemory."""
